-- event_fields

REPLACE INTO event_fields VALUES(1,'date');
REPLACE INTO event_fields VALUES(2,'sensor');
REPLACE INTO event_fields VALUES(3,'device');
REPLACE INTO event_fields VALUES(4,'interface');
REPLACE INTO event_fields VALUES(5,'plugin_id');
REPLACE INTO event_fields VALUES(6,'plugin_sid');
REPLACE INTO event_fields VALUES(7,'protocol');
REPLACE INTO event_fields VALUES(8,'src_ip');
REPLACE INTO event_fields VALUES(9,'src_port');
REPLACE INTO event_fields VALUES(10,'dst_ip');
REPLACE INTO event_fields VALUES(11,'dst_port');
REPLACE INTO event_fields VALUES(12,'username');
REPLACE INTO event_fields VALUES(13,'password');
REPLACE INTO event_fields VALUES(14,'filename');
REPLACE INTO event_fields VALUES(15,'userdata1');
REPLACE INTO event_fields VALUES(16,'userdata2');
REPLACE INTO event_fields VALUES(17,'userdata3');
REPLACE INTO event_fields VALUES(18,'userdata4');
REPLACE INTO event_fields VALUES(19,'userdata5');
REPLACE INTO event_fields VALUES(20,'userdata6');
REPLACE INTO event_fields VALUES(21,'userdata7');
REPLACE INTO event_fields VALUES(22,'userdata8');
REPLACE INTO event_fields VALUES(23,'userdata9');
