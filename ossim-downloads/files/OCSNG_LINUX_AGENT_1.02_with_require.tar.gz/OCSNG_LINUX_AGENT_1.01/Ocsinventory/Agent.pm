###############################################################################
## OCS Inventory NG Client
## Copyleft Pascal DANEK 2005
## Web : http://ocsinventory.sourceforge.net
##
## This code is open source and may be copied and modified as long as the source
## code is always made freely available.
## Please refer to the General Public Licence http://www.gnu.org/ or Licence.txt
################################################################################

package Ocsinventory::Agent;

use strict;

# Options
use Ocsinventory::Agent::Option::Ipdiscover;
use Ocsinventory::Agent::Option::Update;
use Ocsinventory::Agent::Option::Download;

#
$Ocsinventory::Agent::VERSION = '15';

