-- MySQL dump 10.11
--
-- Host: localhost    Database: ossim_acl
-- ------------------------------------------------------
-- Server version	5.0.32-Debian_7etch1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acl`
--

DROP TABLE IF EXISTS `acl`;
CREATE TABLE `acl` (
  `id` int(11) NOT NULL default '0',
  `section_value` varchar(230) NOT NULL default 'system',
  `allow` int(11) NOT NULL default '0',
  `enabled` int(11) NOT NULL default '0',
  `return_value` text,
  `note` text,
  `updated_date` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `enabled_acl` (`enabled`),
  KEY `section_value_acl` (`section_value`),
  KEY `updated_date_acl` (`updated_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acl`
--

LOCK TABLES `acl` WRITE;
/*!40000 ALTER TABLE `acl` DISABLE KEYS */;
INSERT INTO `acl` VALUES (10,'system',1,1,'','',1174843272);
/*!40000 ALTER TABLE `acl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acl_sections`
--

DROP TABLE IF EXISTS `acl_sections`;
CREATE TABLE `acl_sections` (
  `id` int(11) NOT NULL default '0',
  `value` varchar(230) NOT NULL,
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(230) NOT NULL,
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `value_acl_sections` (`value`),
  KEY `hidden_acl_sections` (`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acl_sections`
--

LOCK TABLES `acl_sections` WRITE;
/*!40000 ALTER TABLE `acl_sections` DISABLE KEYS */;
INSERT INTO `acl_sections` VALUES (1,'system',1,'System',0),(2,'user',2,'User',0);
/*!40000 ALTER TABLE `acl_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acl_seq`
--

DROP TABLE IF EXISTS `acl_seq`;
CREATE TABLE `acl_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acl_seq`
--

LOCK TABLES `acl_seq` WRITE;
/*!40000 ALTER TABLE `acl_seq` DISABLE KEYS */;
INSERT INTO `acl_seq` VALUES (10);
/*!40000 ALTER TABLE `acl_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aco`
--

DROP TABLE IF EXISTS `aco`;
CREATE TABLE `aco` (
  `id` int(11) NOT NULL default '0',
  `section_value` varchar(240) NOT NULL default '0',
  `value` varchar(240) NOT NULL,
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `section_value_value_aco` (`section_value`,`value`),
  KEY `hidden_aco` (`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aco`
--

LOCK TABLES `aco` WRITE;
/*!40000 ALTER TABLE `aco` DISABLE KEYS */;
INSERT INTO `aco` VALUES (10,'DomainAccess','All',1,'All',0),(11,'DomainAccess','Login',2,'Login',0),(12,'DomainAccess','Nets',3,'Nets',0),(13,'DomainAccess','Sensors',4,'Sensors',0),(14,'MainMenu','Index',1,'Index',0),(15,'MenuControlPanel','ControlPanelExecutive',1,'ControlPanelExecutive',0),(16,'MenuControlPanel','ControlPanelExecutiveEdit',2,'ControlPanelExecutiveEdit',0),(17,'MenuControlPanel','ControlPanelMetrics',3,'ControlPanelMetrics',0),(18,'MenuControlPanel','ControlPanelAlarms',4,'ControlPanelAlarms',0),(19,'MenuControlPanel','ControlPanelEvents',5,'ControlPanelEvents',0),(20,'MenuControlPanel','ControlPanelVulnerabilities',6,'ControlPanelVulnerabilities',0),(21,'MenuControlPanel','ControlPanelAnomalies',7,'ControlPanelAnomalies',0),(22,'MenuControlPanel','ControlPanelHids',8,'ControlPanelHids',0),(23,'MenuPolicy','PolicyPolicy',1,'PolicyPolicy',0),(24,'MenuPolicy','PolicyHosts',2,'PolicyHosts',0),(25,'MenuPolicy','PolicyNetworks',3,'PolicyNetworks',0),(26,'MenuPolicy','PolicySensors',4,'PolicySensors',0),(27,'MenuPolicy','PolicySignatures',5,'PolicySignatures',0),(28,'MenuPolicy','PolicyPorts',6,'PolicyPorts',0),(29,'MenuPolicy','PolicyActions',7,'PolicyActions',0),(30,'MenuPolicy','PolicyResponses',8,'PolicyResponses',0),(31,'MenuPolicy','PolicyPluginGroups',9,'PolicyPluginGroups',0),(32,'MenuReports','ReportsHostReport',1,'ReportsHostReport',0),(33,'MenuReports','ReportsAlarmReport',2,'ReportsAlarmReport',0),(34,'MenuReports','ReportsSecurityReport',3,'ReportsSecurityReport',0),(35,'MenuReports','ReportsPDFReport',4,'ReportsPDFReport',0),(36,'MenuIncidents','IncidentsIncidents',1,'IncidentsIncidents',0),(37,'MenuIncidents','IncidentsTypes',2,'IncidentsTypes',0),(38,'MenuIncidents','IncidentsReport',3,'IncidentsReport',0),(39,'MenuIncidents','IncidentsTags',4,'IncidentsTags',0),(40,'MenuMonitors','MonitorsSession',1,'MonitorsSession',0),(41,'MenuMonitors','MonitorsNetwork',2,'MonitorsNetwork',0),(42,'MenuMonitors','MonitorsAvailability',3,'MonitorsAvailability',0),(43,'MenuMonitors','MonitorsSensors',4,'MonitorsSensors',0),(44,'MenuMonitors','MonitorsRiskmeter',5,'MonitorsRiskmeter',0),(45,'MenuCorrelation','CorrelationDirectives',1,'CorrelationDirectives',0),(46,'MenuCorrelation','CorrelationCrossCorrelation',2,'CorrelationCrossCorrelation',0),(47,'MenuCorrelation','CorrelationBacklog',3,'CorrelationBacklog',0),(48,'MenuConfiguration','ConfigurationMain',1,'ConfigurationMain',0),(49,'MenuConfiguration','ConfigurationUsers',2,'ConfigurationUsers',0),(50,'MenuConfiguration','ConfigurationPlugins',3,'ConfigurationPlugins',0),(51,'MenuConfiguration','ConfigurationRRDConfig',4,'ConfigurationRRDConfig',0),(52,'MenuConfiguration','ConfigurationHostScan',5,'ConfigurationHostScan',0),(53,'MenuConfiguration','ConfigurationUserActionLog',6,'ConfigurationUserActionLog',0),(54,'MenuConfiguration','ConfigurationEmailTemplate',7,'ConfigurationEmailTemplate',0),(55,'MenuConfiguration','ConfigurationUpgrade',8,'ConfigurationUpgrade',0),(56,'MenuTools','ToolsScan',1,'ToolsScan',0),(57,'MenuTools','ToolsRuleViewer',2,'ToolsRuleViewer',0),(58,'MenuTools','ToolsBackup',3,'ToolsBackup',0),(59,'MenuTools','ToolsUserLog',4,'ToolsUserLog',0);
/*!40000 ALTER TABLE `aco` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aco_map`
--

DROP TABLE IF EXISTS `aco_map`;
CREATE TABLE `aco_map` (
  `acl_id` int(11) NOT NULL default '0',
  `section_value` varchar(230) NOT NULL default '0',
  `value` varchar(230) NOT NULL,
  PRIMARY KEY  (`acl_id`,`section_value`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aco_map`
--

LOCK TABLES `aco_map` WRITE;
/*!40000 ALTER TABLE `aco_map` DISABLE KEYS */;
INSERT INTO `aco_map` VALUES (10,'DomainAccess','All');
/*!40000 ALTER TABLE `aco_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aco_sections`
--

DROP TABLE IF EXISTS `aco_sections`;
CREATE TABLE `aco_sections` (
  `id` int(11) NOT NULL default '0',
  `value` varchar(230) NOT NULL,
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(230) NOT NULL,
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `value_aco_sections` (`value`),
  KEY `hidden_aco_sections` (`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aco_sections`
--

LOCK TABLES `aco_sections` WRITE;
/*!40000 ALTER TABLE `aco_sections` DISABLE KEYS */;
INSERT INTO `aco_sections` VALUES (10,'DomainAccess',1,'DomainAccess',0),(11,'MainMenu',10,'MainMenu',0),(12,'MenuControlPanel',11,'MenuControlPanel',0),(13,'MenuPolicy',12,'MenuPolicy',0),(14,'MenuReports',13,'MenuReports',0),(15,'MenuIncidents',14,'MenuIncidents',0),(16,'MenuMonitors',15,'MenuMonitors',0),(17,'MenuCorrelation',16,'MenuCorrelation',0),(18,'MenuConfiguration',17,'MenuConfiguration',0),(19,'MenuTools',18,'MenuTools',0);
/*!40000 ALTER TABLE `aco_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aco_sections_seq`
--

DROP TABLE IF EXISTS `aco_sections_seq`;
CREATE TABLE `aco_sections_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aco_sections_seq`
--

LOCK TABLES `aco_sections_seq` WRITE;
/*!40000 ALTER TABLE `aco_sections_seq` DISABLE KEYS */;
INSERT INTO `aco_sections_seq` VALUES (19);
/*!40000 ALTER TABLE `aco_sections_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aco_seq`
--

DROP TABLE IF EXISTS `aco_seq`;
CREATE TABLE `aco_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aco_seq`
--

LOCK TABLES `aco_seq` WRITE;
/*!40000 ALTER TABLE `aco_seq` DISABLE KEYS */;
INSERT INTO `aco_seq` VALUES (59);
/*!40000 ALTER TABLE `aco_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aro`
--

DROP TABLE IF EXISTS `aro`;
CREATE TABLE `aro` (
  `id` int(11) NOT NULL default '0',
  `section_value` varchar(240) NOT NULL default '0',
  `value` varchar(240) NOT NULL,
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `section_value_value_aro` (`section_value`,`value`),
  KEY `hidden_aro` (`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aro`
--

LOCK TABLES `aro` WRITE;
/*!40000 ALTER TABLE `aro` DISABLE KEYS */;
INSERT INTO `aro` VALUES (10,'users','admin',1,'Admin',0);
/*!40000 ALTER TABLE `aro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aro_groups`
--

DROP TABLE IF EXISTS `aro_groups`;
CREATE TABLE `aro_groups` (
  `id` int(11) NOT NULL default '0',
  `parent_id` int(11) NOT NULL default '0',
  `lft` int(11) NOT NULL default '0',
  `rgt` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`,`value`),
  UNIQUE KEY `value_aro_groups` (`value`),
  KEY `parent_id_aro_groups` (`parent_id`),
  KEY `lft_rgt_aro_groups` (`lft`,`rgt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aro_groups`
--

LOCK TABLES `aro_groups` WRITE;
/*!40000 ALTER TABLE `aro_groups` DISABLE KEYS */;
INSERT INTO `aro_groups` VALUES (10,0,1,4,'OSSIM','ossim'),(11,10,2,3,'Users','users');
/*!40000 ALTER TABLE `aro_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aro_groups_id_seq`
--

DROP TABLE IF EXISTS `aro_groups_id_seq`;
CREATE TABLE `aro_groups_id_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aro_groups_id_seq`
--

LOCK TABLES `aro_groups_id_seq` WRITE;
/*!40000 ALTER TABLE `aro_groups_id_seq` DISABLE KEYS */;
INSERT INTO `aro_groups_id_seq` VALUES (11);
/*!40000 ALTER TABLE `aro_groups_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aro_groups_map`
--

DROP TABLE IF EXISTS `aro_groups_map`;
CREATE TABLE `aro_groups_map` (
  `acl_id` int(11) NOT NULL default '0',
  `group_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`acl_id`,`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aro_groups_map`
--

LOCK TABLES `aro_groups_map` WRITE;
/*!40000 ALTER TABLE `aro_groups_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `aro_groups_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aro_map`
--

DROP TABLE IF EXISTS `aro_map`;
CREATE TABLE `aro_map` (
  `acl_id` int(11) NOT NULL default '0',
  `section_value` varchar(230) NOT NULL default '0',
  `value` varchar(230) NOT NULL,
  PRIMARY KEY  (`acl_id`,`section_value`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aro_map`
--

LOCK TABLES `aro_map` WRITE;
/*!40000 ALTER TABLE `aro_map` DISABLE KEYS */;
INSERT INTO `aro_map` VALUES (10,'users','admin');
/*!40000 ALTER TABLE `aro_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aro_sections`
--

DROP TABLE IF EXISTS `aro_sections`;
CREATE TABLE `aro_sections` (
  `id` int(11) NOT NULL default '0',
  `value` varchar(230) NOT NULL,
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(230) NOT NULL,
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `value_aro_sections` (`value`),
  KEY `hidden_aro_sections` (`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aro_sections`
--

LOCK TABLES `aro_sections` WRITE;
/*!40000 ALTER TABLE `aro_sections` DISABLE KEYS */;
INSERT INTO `aro_sections` VALUES (10,'users',1,'Users',0);
/*!40000 ALTER TABLE `aro_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aro_sections_seq`
--

DROP TABLE IF EXISTS `aro_sections_seq`;
CREATE TABLE `aro_sections_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aro_sections_seq`
--

LOCK TABLES `aro_sections_seq` WRITE;
/*!40000 ALTER TABLE `aro_sections_seq` DISABLE KEYS */;
INSERT INTO `aro_sections_seq` VALUES (10);
/*!40000 ALTER TABLE `aro_sections_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aro_seq`
--

DROP TABLE IF EXISTS `aro_seq`;
CREATE TABLE `aro_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aro_seq`
--

LOCK TABLES `aro_seq` WRITE;
/*!40000 ALTER TABLE `aro_seq` DISABLE KEYS */;
INSERT INTO `aro_seq` VALUES (10);
/*!40000 ALTER TABLE `aro_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `axo`
--

DROP TABLE IF EXISTS `axo`;
CREATE TABLE `axo` (
  `id` int(11) NOT NULL default '0',
  `section_value` varchar(240) NOT NULL default '0',
  `value` varchar(240) NOT NULL,
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `section_value_value_axo` (`section_value`,`value`),
  KEY `hidden_axo` (`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `axo`
--

LOCK TABLES `axo` WRITE;
/*!40000 ALTER TABLE `axo` DISABLE KEYS */;
/*!40000 ALTER TABLE `axo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `axo_groups`
--

DROP TABLE IF EXISTS `axo_groups`;
CREATE TABLE `axo_groups` (
  `id` int(11) NOT NULL default '0',
  `parent_id` int(11) NOT NULL default '0',
  `lft` int(11) NOT NULL default '0',
  `rgt` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`,`value`),
  UNIQUE KEY `value_axo_groups` (`value`),
  KEY `parent_id_axo_groups` (`parent_id`),
  KEY `lft_rgt_axo_groups` (`lft`,`rgt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `axo_groups`
--

LOCK TABLES `axo_groups` WRITE;
/*!40000 ALTER TABLE `axo_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `axo_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `axo_groups_map`
--

DROP TABLE IF EXISTS `axo_groups_map`;
CREATE TABLE `axo_groups_map` (
  `acl_id` int(11) NOT NULL default '0',
  `group_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`acl_id`,`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `axo_groups_map`
--

LOCK TABLES `axo_groups_map` WRITE;
/*!40000 ALTER TABLE `axo_groups_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `axo_groups_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `axo_map`
--

DROP TABLE IF EXISTS `axo_map`;
CREATE TABLE `axo_map` (
  `acl_id` int(11) NOT NULL default '0',
  `section_value` varchar(230) NOT NULL default '0',
  `value` varchar(230) NOT NULL,
  PRIMARY KEY  (`acl_id`,`section_value`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `axo_map`
--

LOCK TABLES `axo_map` WRITE;
/*!40000 ALTER TABLE `axo_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `axo_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `axo_sections`
--

DROP TABLE IF EXISTS `axo_sections`;
CREATE TABLE `axo_sections` (
  `id` int(11) NOT NULL default '0',
  `value` varchar(230) NOT NULL,
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(230) NOT NULL,
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `value_axo_sections` (`value`),
  KEY `hidden_axo_sections` (`hidden`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `axo_sections`
--

LOCK TABLES `axo_sections` WRITE;
/*!40000 ALTER TABLE `axo_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `axo_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups_aro_map`
--

DROP TABLE IF EXISTS `groups_aro_map`;
CREATE TABLE `groups_aro_map` (
  `group_id` int(11) NOT NULL default '0',
  `aro_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`group_id`,`aro_id`),
  KEY `aro_id` (`aro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `groups_aro_map`
--

LOCK TABLES `groups_aro_map` WRITE;
/*!40000 ALTER TABLE `groups_aro_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups_aro_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups_axo_map`
--

DROP TABLE IF EXISTS `groups_axo_map`;
CREATE TABLE `groups_axo_map` (
  `group_id` int(11) NOT NULL default '0',
  `axo_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`group_id`,`axo_id`),
  KEY `axo_id` (`axo_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `groups_axo_map`
--

LOCK TABLES `groups_axo_map` WRITE;
/*!40000 ALTER TABLE `groups_axo_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups_axo_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phpgacl`
--

DROP TABLE IF EXISTS `phpgacl`;
CREATE TABLE `phpgacl` (
  `name` varchar(230) NOT NULL,
  `value` varchar(230) NOT NULL,
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phpgacl`
--

LOCK TABLES `phpgacl` WRITE;
/*!40000 ALTER TABLE `phpgacl` DISABLE KEYS */;
INSERT INTO `phpgacl` VALUES ('version','3.3.7'),('schema_version','2.1');
/*!40000 ALTER TABLE `phpgacl` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2007-04-12  5:00:49
