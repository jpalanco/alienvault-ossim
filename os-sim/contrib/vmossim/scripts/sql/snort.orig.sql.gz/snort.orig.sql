-- MySQL dump 10.11
--
-- Host: localhost    Database: snort
-- ------------------------------------------------------
-- Server version	5.0.32-Debian_7etch1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acid_ag`
--

DROP TABLE IF EXISTS `acid_ag`;
CREATE TABLE `acid_ag` (
  `ag_id` int(10) unsigned NOT NULL auto_increment,
  `ag_name` varchar(40) default NULL,
  `ag_desc` text,
  `ag_ctime` datetime default NULL,
  `ag_ltime` datetime default NULL,
  PRIMARY KEY  (`ag_id`),
  KEY `ag_id` (`ag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acid_ag`
--

LOCK TABLES `acid_ag` WRITE;
/*!40000 ALTER TABLE `acid_ag` DISABLE KEYS */;
/*!40000 ALTER TABLE `acid_ag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acid_ag_alert`
--

DROP TABLE IF EXISTS `acid_ag_alert`;
CREATE TABLE `acid_ag_alert` (
  `ag_id` int(10) unsigned NOT NULL,
  `ag_sid` int(10) unsigned NOT NULL,
  `ag_cid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`ag_id`,`ag_sid`,`ag_cid`),
  KEY `ag_id` (`ag_id`),
  KEY `ag_sid` (`ag_sid`,`ag_cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acid_ag_alert`
--

LOCK TABLES `acid_ag_alert` WRITE;
/*!40000 ALTER TABLE `acid_ag_alert` DISABLE KEYS */;
/*!40000 ALTER TABLE `acid_ag_alert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acid_event`
--

DROP TABLE IF EXISTS `acid_event`;
CREATE TABLE `acid_event` (
  `sid` int(10) unsigned NOT NULL,
  `cid` int(10) unsigned NOT NULL,
  `signature` int(10) unsigned NOT NULL,
  `sig_name` varchar(255) default NULL,
  `sig_class_id` int(10) unsigned default NULL,
  `sig_priority` int(10) unsigned default NULL,
  `timestamp` datetime NOT NULL,
  `ip_src` int(10) unsigned default NULL,
  `ip_dst` int(10) unsigned default NULL,
  `ip_proto` int(11) default NULL,
  `layer4_sport` int(10) unsigned default NULL,
  `layer4_dport` int(10) unsigned default NULL,
  `ossim_type` int(11) default '1',
  `ossim_priority` int(11) default '1',
  `ossim_reliability` int(11) default '1',
  `ossim_asset_src` int(11) default '1',
  `ossim_asset_dst` int(11) default '1',
  `ossim_risk_c` int(11) default '1',
  `ossim_risk_a` int(11) default '1',
  PRIMARY KEY  (`sid`,`cid`),
  KEY `signature` (`signature`),
  KEY `sig_name` (`sig_name`),
  KEY `sig_class_id` (`sig_class_id`),
  KEY `sig_priority` (`sig_priority`),
  KEY `timestamp` (`timestamp`),
  KEY `ip_src` (`ip_src`),
  KEY `ip_dst` (`ip_dst`),
  KEY `ip_proto` (`ip_proto`),
  KEY `layer4_sport` (`layer4_sport`),
  KEY `layer4_dport` (`layer4_dport`),
  KEY `acid_event_ossim_type` (`ossim_type`),
  KEY `acid_event_ossim_priority` (`ossim_priority`),
  KEY `acid_event_ossim_reliability` (`ossim_reliability`),
  KEY `acid_event_ossim_asset_src` (`ossim_asset_src`),
  KEY `acid_event_ossim_asset_dst` (`ossim_asset_dst`),
  KEY `acid_event_ossim_risk_c` (`ossim_risk_c`),
  KEY `acid_event_ossim_risk_a` (`ossim_risk_a`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acid_event`
--

LOCK TABLES `acid_event` WRITE;
/*!40000 ALTER TABLE `acid_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `acid_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `acid_ip_cache`
--

DROP TABLE IF EXISTS `acid_ip_cache`;
CREATE TABLE `acid_ip_cache` (
  `ipc_ip` int(10) unsigned NOT NULL,
  `ipc_fqdn` varchar(50) default NULL,
  `ipc_dns_timestamp` datetime default NULL,
  `ipc_whois` text,
  `ipc_whois_timestamp` datetime default NULL,
  PRIMARY KEY  (`ipc_ip`),
  KEY `ipc_ip` (`ipc_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acid_ip_cache`
--

LOCK TABLES `acid_ip_cache` WRITE;
/*!40000 ALTER TABLE `acid_ip_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `acid_ip_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `base_roles`
--

DROP TABLE IF EXISTS `base_roles`;
CREATE TABLE `base_roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(20) NOT NULL,
  `role_desc` varchar(75) NOT NULL,
  PRIMARY KEY  (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `base_roles`
--

LOCK TABLES `base_roles` WRITE;
/*!40000 ALTER TABLE `base_roles` DISABLE KEYS */;
INSERT INTO `base_roles` VALUES (1,'Admin','Administrator'),(10,'User','Authenticated User'),(10000,'Anonymous','Anonymous User'),(50,'ag_editor','Alert Group Editor');
/*!40000 ALTER TABLE `base_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `base_users`
--

DROP TABLE IF EXISTS `base_users`;
CREATE TABLE `base_users` (
  `usr_id` int(11) NOT NULL,
  `usr_login` varchar(25) NOT NULL,
  `usr_pwd` varchar(32) NOT NULL,
  `usr_name` varchar(75) NOT NULL,
  `role_id` int(11) NOT NULL,
  `usr_enabled` int(11) NOT NULL,
  PRIMARY KEY  (`usr_id`),
  KEY `usr_login` (`usr_login`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `base_users`
--

LOCK TABLES `base_users` WRITE;
/*!40000 ALTER TABLE `base_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `base_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data`
--

DROP TABLE IF EXISTS `data`;
CREATE TABLE `data` (
  `sid` int(10) unsigned NOT NULL,
  `cid` int(10) unsigned NOT NULL,
  `data_payload` text,
  PRIMARY KEY  (`sid`,`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data`
--

LOCK TABLES `data` WRITE;
/*!40000 ALTER TABLE `data` DISABLE KEYS */;
/*!40000 ALTER TABLE `data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detail`
--

DROP TABLE IF EXISTS `detail`;
CREATE TABLE `detail` (
  `detail_type` tinyint(3) unsigned NOT NULL,
  `detail_text` text NOT NULL,
  PRIMARY KEY  (`detail_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail`
--

LOCK TABLES `detail` WRITE;
/*!40000 ALTER TABLE `detail` DISABLE KEYS */;
INSERT INTO `detail` VALUES (0,'fast'),(1,'full');
/*!40000 ALTER TABLE `detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encoding`
--

DROP TABLE IF EXISTS `encoding`;
CREATE TABLE `encoding` (
  `encoding_type` tinyint(3) unsigned NOT NULL,
  `encoding_text` text NOT NULL,
  PRIMARY KEY  (`encoding_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `encoding`
--

LOCK TABLES `encoding` WRITE;
/*!40000 ALTER TABLE `encoding` DISABLE KEYS */;
INSERT INTO `encoding` VALUES (0,'hex'),(1,'base64'),(2,'ascii');
/*!40000 ALTER TABLE `encoding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
CREATE TABLE `event` (
  `sid` int(10) unsigned NOT NULL,
  `cid` int(10) unsigned NOT NULL,
  `signature` int(10) unsigned NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY  (`sid`,`cid`),
  KEY `sig` (`signature`),
  KEY `time` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extra_data`
--

DROP TABLE IF EXISTS `extra_data`;
CREATE TABLE `extra_data` (
  `sid` bigint(20) NOT NULL,
  `cid` bigint(20) NOT NULL,
  `filename` varchar(255) default NULL,
  `username` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  `userdata1` varchar(255) default NULL,
  `userdata2` varchar(255) default NULL,
  `userdata3` varchar(255) default NULL,
  `userdata4` varchar(255) default NULL,
  `userdata5` varchar(255) default NULL,
  `userdata6` varchar(255) default NULL,
  `userdata7` varchar(255) default NULL,
  `userdata8` varchar(255) default NULL,
  `userdata9` varchar(255) default NULL,
  PRIMARY KEY  (`sid`,`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `extra_data`
--

LOCK TABLES `extra_data` WRITE;
/*!40000 ALTER TABLE `extra_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `extra_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `icmphdr`
--

DROP TABLE IF EXISTS `icmphdr`;
CREATE TABLE `icmphdr` (
  `sid` int(10) unsigned NOT NULL,
  `cid` int(10) unsigned NOT NULL,
  `icmp_type` tinyint(3) unsigned NOT NULL,
  `icmp_code` tinyint(3) unsigned NOT NULL,
  `icmp_csum` smallint(5) unsigned default NULL,
  `icmp_id` smallint(5) unsigned default NULL,
  `icmp_seq` smallint(5) unsigned default NULL,
  PRIMARY KEY  (`sid`,`cid`),
  KEY `icmp_type` (`icmp_type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `icmphdr`
--

LOCK TABLES `icmphdr` WRITE;
/*!40000 ALTER TABLE `icmphdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `icmphdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iphdr`
--

DROP TABLE IF EXISTS `iphdr`;
CREATE TABLE `iphdr` (
  `sid` int(10) unsigned NOT NULL,
  `cid` int(10) unsigned NOT NULL,
  `ip_src` int(10) unsigned NOT NULL,
  `ip_dst` int(10) unsigned NOT NULL,
  `ip_ver` tinyint(3) unsigned default NULL,
  `ip_hlen` tinyint(3) unsigned default NULL,
  `ip_tos` tinyint(3) unsigned default NULL,
  `ip_len` smallint(5) unsigned default NULL,
  `ip_id` smallint(5) unsigned default NULL,
  `ip_flags` tinyint(3) unsigned default NULL,
  `ip_off` smallint(5) unsigned default NULL,
  `ip_ttl` tinyint(3) unsigned default NULL,
  `ip_proto` tinyint(3) unsigned NOT NULL,
  `ip_csum` smallint(5) unsigned default NULL,
  PRIMARY KEY  (`sid`,`cid`),
  KEY `ip_src` (`ip_src`),
  KEY `ip_dst` (`ip_dst`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `iphdr`
--

LOCK TABLES `iphdr` WRITE;
/*!40000 ALTER TABLE `iphdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `iphdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opt`
--

DROP TABLE IF EXISTS `opt`;
CREATE TABLE `opt` (
  `sid` int(10) unsigned NOT NULL,
  `cid` int(10) unsigned NOT NULL,
  `optid` int(10) unsigned NOT NULL,
  `opt_proto` tinyint(3) unsigned NOT NULL,
  `opt_code` tinyint(3) unsigned NOT NULL,
  `opt_len` smallint(6) default NULL,
  `opt_data` text,
  PRIMARY KEY  (`sid`,`cid`,`optid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opt`
--

LOCK TABLES `opt` WRITE;
/*!40000 ALTER TABLE `opt` DISABLE KEYS */;
/*!40000 ALTER TABLE `opt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ossim_event`
--

DROP TABLE IF EXISTS `ossim_event`;
CREATE TABLE `ossim_event` (
  `sid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `priority` int(11) default '1',
  `reliability` int(11) default '1',
  `asset_src` int(11) default '1',
  `asset_dst` int(11) default '1',
  `risk_c` int(11) default '1',
  `risk_a` int(11) default '1',
  `plugin_id` int(11) NOT NULL,
  `plugin_sid` int(11) NOT NULL,
  PRIMARY KEY  (`sid`,`cid`),
  KEY `type` (`type`),
  KEY `priority` (`priority`),
  KEY `reliability` (`reliability`),
  KEY `asset_src` (`asset_src`),
  KEY `asset_dst` (`asset_dst`),
  KEY `risk_c` (`risk_c`),
  KEY `risk_a` (`risk_a`),
  KEY `plugin_id` (`plugin_id`),
  KEY `plugin_sid` (`plugin_sid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ossim_event`
--

LOCK TABLES `ossim_event` WRITE;
/*!40000 ALTER TABLE `ossim_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `ossim_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reference`
--

DROP TABLE IF EXISTS `reference`;
CREATE TABLE `reference` (
  `ref_id` int(10) unsigned NOT NULL auto_increment,
  `ref_system_id` int(10) unsigned NOT NULL,
  `ref_tag` text NOT NULL,
  PRIMARY KEY  (`ref_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reference`
--

LOCK TABLES `reference` WRITE;
/*!40000 ALTER TABLE `reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reference_system`
--

DROP TABLE IF EXISTS `reference_system`;
CREATE TABLE `reference_system` (
  `ref_system_id` int(10) unsigned NOT NULL auto_increment,
  `ref_system_name` varchar(20) default NULL,
  PRIMARY KEY  (`ref_system_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reference_system`
--

LOCK TABLES `reference_system` WRITE;
/*!40000 ALTER TABLE `reference_system` DISABLE KEYS */;
/*!40000 ALTER TABLE `reference_system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema`
--

DROP TABLE IF EXISTS `schema`;
CREATE TABLE `schema` (
  `vseq` int(10) unsigned NOT NULL,
  `ctime` datetime NOT NULL,
  PRIMARY KEY  (`vseq`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schema`
--

LOCK TABLES `schema` WRITE;
/*!40000 ALTER TABLE `schema` DISABLE KEYS */;
INSERT INTO `schema` VALUES (106,'2007-04-12 00:59:12');
/*!40000 ALTER TABLE `schema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sensor`
--

DROP TABLE IF EXISTS `sensor`;
CREATE TABLE `sensor` (
  `sid` int(10) unsigned NOT NULL auto_increment,
  `hostname` text,
  `interface` text,
  `filter` text,
  `detail` tinyint(4) default NULL,
  `encoding` tinyint(4) default NULL,
  `last_cid` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sensor`
--

LOCK TABLES `sensor` WRITE;
/*!40000 ALTER TABLE `sensor` DISABLE KEYS */;
/*!40000 ALTER TABLE `sensor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sig_class`
--

DROP TABLE IF EXISTS `sig_class`;
CREATE TABLE `sig_class` (
  `sig_class_id` int(10) unsigned NOT NULL auto_increment,
  `sig_class_name` varchar(60) NOT NULL,
  PRIMARY KEY  (`sig_class_id`),
  KEY `sig_class_id` (`sig_class_id`),
  KEY `sig_class_name` (`sig_class_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sig_class`
--

LOCK TABLES `sig_class` WRITE;
/*!40000 ALTER TABLE `sig_class` DISABLE KEYS */;
/*!40000 ALTER TABLE `sig_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sig_reference`
--

DROP TABLE IF EXISTS `sig_reference`;
CREATE TABLE `sig_reference` (
  `sig_id` int(10) unsigned NOT NULL,
  `ref_seq` int(10) unsigned NOT NULL,
  `ref_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`sig_id`,`ref_seq`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sig_reference`
--

LOCK TABLES `sig_reference` WRITE;
/*!40000 ALTER TABLE `sig_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sig_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `signature`
--

DROP TABLE IF EXISTS `signature`;
CREATE TABLE `signature` (
  `sig_id` int(10) unsigned NOT NULL auto_increment,
  `sig_name` varchar(255) NOT NULL,
  `sig_class_id` int(10) unsigned NOT NULL,
  `sig_priority` int(10) unsigned default NULL,
  `sig_rev` int(10) unsigned default NULL,
  `sig_sid` int(10) unsigned default NULL,
  PRIMARY KEY  (`sig_id`),
  KEY `sign_idx` (`sig_name`(20)),
  KEY `sig_class_id_idx` (`sig_class_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signature`
--

LOCK TABLES `signature` WRITE;
/*!40000 ALTER TABLE `signature` DISABLE KEYS */;
/*!40000 ALTER TABLE `signature` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tcphdr`
--

DROP TABLE IF EXISTS `tcphdr`;
CREATE TABLE `tcphdr` (
  `sid` int(10) unsigned NOT NULL,
  `cid` int(10) unsigned NOT NULL,
  `tcp_sport` smallint(5) unsigned NOT NULL,
  `tcp_dport` smallint(5) unsigned NOT NULL,
  `tcp_seq` int(10) unsigned default NULL,
  `tcp_ack` int(10) unsigned default NULL,
  `tcp_off` tinyint(3) unsigned default NULL,
  `tcp_res` tinyint(3) unsigned default NULL,
  `tcp_flags` tinyint(3) unsigned NOT NULL,
  `tcp_win` smallint(5) unsigned default NULL,
  `tcp_csum` smallint(5) unsigned default NULL,
  `tcp_urp` smallint(5) unsigned default NULL,
  PRIMARY KEY  (`sid`,`cid`),
  KEY `tcp_sport` (`tcp_sport`),
  KEY `tcp_dport` (`tcp_dport`),
  KEY `tcp_flags` (`tcp_flags`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tcphdr`
--

LOCK TABLES `tcphdr` WRITE;
/*!40000 ALTER TABLE `tcphdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `tcphdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `udphdr`
--

DROP TABLE IF EXISTS `udphdr`;
CREATE TABLE `udphdr` (
  `sid` int(10) unsigned NOT NULL,
  `cid` int(10) unsigned NOT NULL,
  `udp_sport` smallint(5) unsigned NOT NULL,
  `udp_dport` smallint(5) unsigned NOT NULL,
  `udp_len` smallint(5) unsigned default NULL,
  `udp_csum` smallint(5) unsigned default NULL,
  PRIMARY KEY  (`sid`,`cid`),
  KEY `udp_sport` (`udp_sport`),
  KEY `udp_dport` (`udp_dport`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `udphdr`
--

LOCK TABLES `udphdr` WRITE;
/*!40000 ALTER TABLE `udphdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `udphdr` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2007-04-12  5:00:31
