#!/bin/bash
chown www-data.ossec /var/ossec/etc/client.keys
chmod 660 /var/ossec/etc/client.keys
