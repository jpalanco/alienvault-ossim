#!/bin/sh
makensis ui.nsi
makensis ossec-installer.nsi
